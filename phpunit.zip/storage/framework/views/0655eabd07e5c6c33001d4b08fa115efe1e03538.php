<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session('alert-'.$msg)): ?>
        <div class="alert alert-<?php echo e($msg); ?> alert-dismissible fade show my-2"><?php echo e(session('alert-'.$msg)); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</button>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/layouts/errors.blade.php ENDPATH**/ ?>