<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body text-primrayColor table-responsive">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="card-title">Payment Of Memorial Service</p>
                        </div>
                        <div class="col-md-6 text-end d-flex justify-content-end align-items-center gap-2">
                            <a href=""
                               class="text-decoration-none text-dark bg-theme border-0 py-1 px-2 rounded text-xl flex flex-row gap-1 align-items-center">
                                <img class="d-block w-[30px] max-w-[30px] leading-[30px]" src="<?php echo e(asset('./images/print.svg')); ?>">
                            </a>
                        </div>
                    </div>
                    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table id="example" class="table table-theme">
                        <thead>
                            <tr>
                                <th class="">Dead Person Name </th>
                                <th class="">IC No.</th>
                                <th class="">Address</th>
                                <th class="">Date of Death</th>
                                <th class="">Amount Paid</th>
                                <th class="">Burial Contact Person</th>
                                <th class=""><span class="sr-only">Action</span></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $deaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $death): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $member = $death->member; ?>
                        <tr>
                            <td><?php echo e($member['name']); ?></td>
                            <td><?php echo e($member['ic_no']); ?></td>
                            <td><?php echo e($member['home_address1']); ?></td>
                            <td><?php echo e(memberStatus($member['member_status_ids'])); ?></td>
                            <td><?php echo e($death['service_cost']); ?></td>
                            <td><?php echo e($death['burial_contact_person']); ?></td>
                            <td>
                                <div class="flex flex-row gap-2">
                                    <a href="<?php echo e(route('member.edit', $member['id'])); ?>"
                                       class="text-decoration-none text-dark bg-theme border-0 py-2 px-2 rounded text-xl flex flex-row gap-1 align-items-center">
                                        <i class="fa-solid fa-pencil w-[30px] text-center leading-[30px]"></i>
                                    </a>
                                    <a href="<?php echo e(route('burial.payment.create', $death->id)); ?>"
                                       class="text-decoration-none text-dark bg-theme border-0 py-1 px-2 rounded text-xl flex flex-row gap-1 align-items-center d-block">
                                        <img class="d-block w-[30px] max-w-[30px] leading-[30px]" src="<?php echo e(asset('./images/payment-icon1.svg')); ?>">
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                responsive: {
                    details: false
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/burial-payment.blade.php ENDPATH**/ ?>
