<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <!-- plugins:css -->
    <link rel="stylesheet" href="">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="">
    <!-- End plugin css for this page -->
    <!-- inject:css -->

<!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>"/>
    <!-- Scripts -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/base/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/DataTables/datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dist/css/dropify.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')([
    'resources/sass/app.scss',
    'resources/js/app.js',
    'resources/css/app.css',
    ]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>
<body>
<div id="app">
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <div class="fixed-top bg-theme">
            <nav class="top_nav border-bottom border-top my-2 py-2">
                <div class="container-fluid">
                    <div class="d-flex gap-5 align-items-center">
                        <div class="">
                            <img src="<?php echo e(asset('./images/logo.png')); ?>" alt="" class="logo w-[60px]">
                        </div>
                        <div
                            class=" d-flex align-items-md-end align-items-satart flex-column flex-md-row gap-0 gap-md-4">
                            <h3 class="mb-0 lh-1">Masjid Jamek Sultan Abdul Aziz</h3>
                            <p class="mb-0 leading-[1.3]">Petaling Jaya, Selangor, Malaysia</p>
                        </div>
                    </div>
                </div>
            </nav>
            <nav class="navbar col-lg-12 col-12 pb-1 pt-0 d-flex flex-row">
                <div class="navbar-brand-wrapper d-flex justify-content-center">
                    <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                        <div class="user">
                            <a class="navbar-brand brand-logo" href="index.html">Admin User</a>
                        </div>
                        <button class="navbar-toggler navbar-toggler align-self-center" type="button"
                                data-toggle="minimize">
                            <img src="<?php echo e(asset('/images/bars.svg')); ?>">
                        </button>
                    </div>
                </div>
                <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                    <ul class="navbar-nav navbar-nav-left">
                        <li class="nav-item nav-profile dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center p-0" href="#"
                               data-toggle="dropdown" id="profileDropdown">
                                <img src="<?php echo e(asset('images/faces/face5.jpg')); ?>" alt="profile"/>
                                <span class="nav-profile-name">Louis Barnett</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                                 aria-labelledby="profileDropdown">
                                <a class="dropdown-item">
                                    <i class="mdi mdi-settings text-primary"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="mdi mdi-logout text-primary"></i>
                                    Logout
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </a>
                            </div>
                        </li>
                    </ul>
                    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                            data-toggle="offcanvas">
                        <img src="<?php echo e(asset('/images/bars.svg')); ?>">
                    </button>
                </div>
            </nav>
        </div>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('layouts/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-dark text-center text-sm-left d-block d-sm-inline-block"><i class="mdi mdi-copyright"></i> Copyright Masjid Jamek Sultan Abdul Aziz Petaling Jaya 2022</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo e(asset('assets/vendors/base/vendor.bundle.base.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?> "></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="<?php echo e(asset('assets/vendors/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="<?php echo e(asset('assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/DataTables/datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/DataTables/datatables.js')); ?>"></script>
    <!-- End custom js for this page-->
    <!-- End custom js for this page-->
<?php echo $__env->yieldContent('script'); ?>
</body>

</html>

<?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/layouts/app.blade.php ENDPATH**/ ?>