<?php
    use Illuminate\Support\Facades\Route;
    $route_name = Route::currentRouteName()
?>
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item <?php if(in_array($route_name, array('member.index', 'member.create'))): ?>) active <?php endif; ?>">
            <a class="nav-link" data-toggle="collapse" href="#database" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Database</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse  <?php if($route_name == 'member.create'): ?> show <?php endif; ?>" id="database">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item  <?php if($route_name == 'member.create'): ?> active <?php endif; ?>"><a class="nav-link"
                                                                                               href="<?php echo e(route('member.index')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/add-user.svg')); ?>"/>List</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#memorial_services" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Memorial Service</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="memorial_services">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('khairat-member.index')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/add-user.svg')); ?>"/>
                            Khairat Membership</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('death.index')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/death.svg')); ?>"/>Death</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('burial.payment.index')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/payment.svg')); ?>"/>Burial Payment</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#welfare_services" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Welfare Service</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="welfare_services">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('welfare.index')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/grid-view-icon.svg')); ?>"/>All Category</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('welfare', 'orphan')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/orphan.svg')); ?>"/>Orphan</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('welfare', 'asnaf')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/asnaf.svg')); ?>"/>Asnaf</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('welfare', 'education')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/education.svg')); ?>"/>Education</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('welfare', 'others')); ?>"><img
                                class="h-[20px] w-[20px] me-3" src="<?php echo e(asset('/images/asnaf.svg')); ?>"/>Others</a>
                    </li>
                </ul>
            </div>
        </li>
    </ul>
</nav>
<?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>