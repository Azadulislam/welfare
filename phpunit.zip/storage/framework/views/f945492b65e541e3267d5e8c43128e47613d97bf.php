<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Registration Death Khairat Member</h4>
                            </div>
                        </div>
                        <form class="forms-sample" action="<?php echo e(route('khairat-member.store')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-12">
                                    <select name="member_id" class="form-control" id="search_key">
                                    </select>
                                    <input type="hidden" name="member_id" value="<?php echo e(old('member_id')); ?>">
                                    <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php $__currentLoopData = array(
                                        array('label'=>'Full Name', 'name'=>'name'),
                                        array('label'=>'IC No', 'name'=>'ic_no')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 col-12">
                                        <div class="form-group row align-items-center required">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($info['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="text" name="<?php echo e($info['name']); ?>" readonly
                                                       value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group is-invalid row required align-items-center">
                                <label class="col-md-3 col-6 mb-0">
                                    <span>Member Type</span>
                                </label>
                                <div class="col-md-9 col-6 row">
                                    <?php $__currentLoopData = $member_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <?php echo e($job['name']); ?>

                                                    <input type="checkbox" name="member_status_ids[]" onclick="event.preventDefault()" <?php if(is_array(old('member_status_ids'))): ?> <?php if( in_array($job['id'], old('member_status_ids') )): ?> checked
                                                           <?php endif; ?> <?php endif; ?> value="<?php echo e($job['id']); ?>"
                                                           class="form-check-input rounded-0">
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['member_status_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Date of Birth', 'name'=>'birth_date', 'type' => 'date', 'required' => true),
                                        array('label'=>'Citizenship', 'name'=>'citizenship', 'type' => 'text', 'required'=> true),
                                        array('label'=>'Gender', 'name'=>'gender', 'type' => 'text', 'required' => false),
                                        array('label'=>'Race', 'name'=>'race', 'type' => 'text', 'required' => false),
                                        array('label'=>'Religion', 'name'=>'religion', 'type' => 'text', 'required' => false),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control" readonly/>
                                            <?php elseif($data['type'] == 'select'): ?>
                                                <select class="form-control" name="<?php echo e($data['name']); ?>" readonly>
                                                    <option value=""><?php echo e($data['default']); ?></option>
                                                    <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value['id'] ?? $value); ?>"
                                                                <?php if(old($data['name']) == $value['id'] ?? $value): ?> selected <?php endif; ?>><?php echo e($value['name'] ?? $value); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group is-invalid row align-items-center required">
                                <label class="col-md-3 col-6 mb-0">
                                    <span>Marital Status</span>
                                </label>
                                <div class="col-md-9 col-6 row">
                                    <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label" onclick="event.preventDefault()">
                                                    <?php echo e($status['name']); ?>

                                                    <input type="radio" name="marital_status_id"
                                                           <?php if(old('marital_status_id') == $status['id']): ?> checked
                                                           <?php endif; ?> value="<?php echo e($status['id']); ?>"
                                                           class="form-check-input rounded-0">
                                                </label>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['member_status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Membership Start Date', 'name'=>'member_start_date', 'type' => 'date', 'required' => false),
                                        array('label'=>'Approval Date', 'name'=>'approval_date', 'type' => 'date', 'required' => false),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                            <?php endif; ?>
                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        let keywordEl = $('#search_key');
        $eventSelect = keywordEl.select2({
            placeholder: "Search Name/IC No",
            ajax: {
                method: 'POST',
                url: '/search-member',
                data: function (params) {
                    console.log(params)
                    var query = {
                        search: params.term,
                        type: 'public'
                    }
                    return query;
                },
                processResults: function (data) {
                    let items = [];
                    $(data).each((index, item)=>{
                        items.push({id: item.id, text: item.name})
                    })
                    return {
                        results:items,
                    };
                }
            },
            change: (e)=>{
                console.log(e)
            }

        });
        $eventSelect.on("change", function (e) { fetchData($(e.target).val()) });
        function fetchData(id){
            $.ajax({
                'url': '/member-data/'+id,
                'Method': 'POST',
                'content-type': 'json',
                'processData': false,
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                success:(response)=> {
                    let names = [
                        {name: 'member_id', value: response.id},
                        {name: 'name', value: response.name},
                        {name: 'ic_no', value: response.ic_no},
                        {name: 'birth_date', value: response.birth_date},
                        {name: 'citizenship', value: response.citizenship},
                        {name: 'gender', value: response.gender},
                        {name: 'race', value: response.race},
                        {name: 'religion', value: response.religion},
                    ]
                    $(names).each((index, name) => {
                        let attr = name.name;
                        $('[name="' + name.name + '"]').val(name.value)
                    })
                    $('[name="member_status_ids[]"]').each((index, checkbox)=>{
                        let ids = JSON.parse(response.member_status_ids);
                        if(Array.isArray(ids)){
                            if(ids.includes(checkbox.value)){
                                $(checkbox).prop('checked', true)
                            }
                        }else{
                            $(checkbox).prop('checked', false)
                        }
                    })
                    $('[name="marital_status_id"]').each((index, checkbox)=>{
                        let ids = response.marital_status_id;
                        if(ids == checkbox.value){
                            $(checkbox).prop('checked', true)
                        }

                    })
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/add-khairat.blade.php ENDPATH**/ ?>