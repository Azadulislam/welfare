<?php $__env->startSection('content'); ?>
    <?php $member = $welfare_service->member; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Payment On Selected Help Category</h4>
                            </div>
                        </div>
                        <form class="forms-sample" action="<?php echo e(route('help-provided.store')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" value="<?php echo e($member->id); ?>" name="id">
                            <input type="hidden" name="welfare_id" value="<?php echo e($welfare_service->id); ?>">
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Applicant Name', 'name'=>'name', 'value' => $member->name),
                                        array('label'=>'Telephone (Home)', 'name'=>'telephone_one', 'value' => $member->telephone_one),
                                        array('label'=>'IC No', 'name'=>'ic_no', 'value' => $member->ic_no),
                                        array('label'=>'Marital Status', 'name'=>'marital_status', 'value' => $member->marital_status->name),
                                        array('label'=>'Jalan', 'name'=>'jalan', 'value' => ''),
                                        array('label'=>'Date Of Birth', 'name'=>'birth_date', 'value' => $member->birth_date),
                                        array('label'=>'Seksyen', 'name'=>'seksyen', 'value' => ''),
                                        array('label'=>'Date Starts of Stay', 'name'=>'start_of_stay', 'value' => $member->start_of_stay)
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group row align-items-center">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($info['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="text" name="<?php echo e($info['name']); ?>" readonly
                                                       value="<?php echo e($info['value']); ?>" class="form-control"/>
                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Date', 'name'=>'date', 'type' => 'date', 'required' => true),
                                        array('label'=>'Help Category', 'name'=>'help_cat_id', 'type' => 'select', 'required'=> true, 'values' => $help_cats, 'default' => 'Select Country'),
                                        array('label'=>'Total RM', 'name'=>'service_cost', 'type' => 'text', 'required' => true),
                                        array('label'=>'Type Of Help', 'name'=>'type_of_help', 'type' => 'select', 'required' => false, 'default' => 'Select Gender', 'values' => $citizenshipCounties)
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group row <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                            <?php elseif($data['type'] == 'select'): ?>
                                                <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                    <option value=""><?php echo e($data['default']); ?></option>
                                                    <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value['id']); ?>"
                                                                <?php if(old($data['name']) == $value['id']): ?> selected <?php endif; ?>><?php echo e($value['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                            </div>

                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleTextarea1">Summary</label>
                                <textarea class="form-control" name="summary" id="exampleTextarea1" rows="4"><?php echo e(old('summary')); ?></textarea>
                                <?php $__errorArgs = ['summary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Authorized By', 'name'=>'authorized_by', 'type' => 'text', 'required' => true),
                                        array('label'=>'Authorized Date', 'name'=>'authorized_date', 'type' => 'date', 'required'=> true),
                                        array('label'=>'Name Of Help Recipient', 'name'=>'recipient_name', 'type' => 'text', 'required' => true),
                                        array('label'=>'Date Received', 'name'=>'date_payout', 'type' => 'date', 'required' => false)
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group row <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                            <?php elseif($data['type'] == 'select'): ?>
                                                <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                    <option value=""><?php echo e($data['default']); ?></option>
                                                    <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value['id']); ?>"
                                                                <?php if(old($data['name']) == $value['id']): ?> selected <?php endif; ?>><?php echo e($value['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                            </div>

                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row">
                                <?php for($i=0;$i< 4; $i++): ?>
                                    <div class="form-group mb-3 col-md-3 col-sm-4 col-6">
                                        <label for="exampleInputCity1">Image file</label>
                                        <input type="file" name="images[]" class="dropify" data-height="250"/>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dist/js/dropify.js')); ?>"></script>
    <script>
        $('.dropify').dropify();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/payment.blade.php ENDPATH**/ ?>