<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Registration for Dependants</h4>
                            </div>
                        </div>

                        <div class="form-group row align-items-center">
                            <label class="col-sm-3 col-form-label">Full Name</label>
                            <div class="col-sm-9">
                                <?php echo e($member['name']); ?>

                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label class="col-sm-3 col-form-label">IC No</label>
                            <div class="col-sm-9">
                                <?php echo e($member['ic_no']); ?>

                            </div>
                        </div>

                        <div class="form-group row align-items-center">
                            <label class="col-sm-3 col-form-label">Membership Status</label>
                            <div class="col-sm-9">
                                <div class="row">
                                    <?php $__currentLoopData = $memberStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label" onclick="event.preventDefault()">
                                                    <input type="checkbox" name="place_status" value="<?php echo e($status['id']); ?>" <?php echo e(oldCheckBox($status['id'], $member['member_status_ids'])); ?>

                                                           class="form-check-input rounded-0">
                                                    <?php echo e($status['name']); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = array(
                                    array('label'=>'Date Of Birth', 'name'=>'birth_date', 'value'=> $member['birth_date']),
                                    array('label'=>'Age', 'name'=>'age', 'value'=> age($member['birth_date'])),
                                    array('label'=>'Nationality', 'name'=>'citizenship', 'value'=> $member->citizenshipCountry->name),
                                    array('label'=>'Gender', 'name'=>'gender', 'value'=> $member['gender']),
                                    array('label'=>'Race', 'name'=>'race', 'value'=> $member['']),
                                    array('label'=>'Religion', 'name'=>'religion', 'value'=> $member['religion']),
                                    ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group row align-items-center">
                                        <label class="col-sm-3 col-form-label"><?php echo e($info['label']); ?></label>
                                        <div class="col-sm-9">
                                            <?php echo e($info['value']); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group row align-items-center">
                            <label class="col-sm-3 col-form-label">Marital Status</label>
                            <div class="col-sm-9">
                                <div class="row">
                                    <?php $__currentLoopData = $maritalStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label" onclick="event.preventDefault()">
                                                    <input type="radio" name="place_status" value="<?php echo e($status['id']); ?>" <?php if(old('marital_status_id', $member->marital_status_id) == $status['id']): ?> checked
                                                           <?php endif; ?>
                                                    class="form-check-input rounded-0">
                                                    <?php echo e($status['name']); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="">
                                <span>Current Home Address</span>
                            </label>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Address Line 1', 'name'=>'home_address1', 'required' => true, 'value' => $member->home_address1),
                                        array('label'=>'Address Line 2', 'name'=>'home_address2', 'required' => false, 'value' => $member->home_address3),
                                        array('label'=>'Address Line 3', 'name'=>'home_address3', 'required' => false, 'value' => $member->home_address2),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 col-12">
                                        <div
                                            class="form-group row align-items-center">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($info['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                                <?php echo e($info['value']); ?>

                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Postcode', 'name'=>'home_postcode', 'required' => false, 'value'=> $member->home_postcode),
                                        array('label'=>'Town', 'name'=>'home_city', 'required' => false, 'value' => $member->home_city),
                                        array('label'=>'District', 'name'=>'home_district', 'required' => false, 'value' => $member->home_district),
                                        array('label'=>'State', 'name'=>'home_state', 'required'=> false,'value' => $member->home_state),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <div class="">
                                                <?php echo e($data['value']); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-12">
                                    <div class="form-group row align-items-center">
                                        <label class="col-sm-3 col-form-label">Current Home Status</label>
                                        <div class="col-sm-9">
                                            <?php echo e($member->home_stuts); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Telephone (House)', 'required' => false, 'value'=> $member->telephone_one),
                                        array('label'=>'Hand phone:', 'required' => false, 'value' => $member->mobile_phone),
                                        array('label'=>'Email', 'required' => false, 'value' => $member->email),
                                        array('label'=>'Date starts of Staying', 'required'=> false,'value' => $member->start_of_stay),
                                        array('label'=>'Job', 'required'=> false,'value' => $member->job),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <div class="">
                                                <?php echo e($data['value']); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="row">
                            <?php echo $__env->make('layouts.dependents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('#customRelationShip').css('display', 'none');
        $('#custom_name').css('display', 'none');
        $('#telephone').prop('readonly', true);
        function checkNew(){
            if($('input[name="custom"]').prop("checked") == true){
                $('#custom_name').css('display', 'block');
                $('#exiting_name').css('display', 'none');
                $('#telephone').prop('readonly', false);
                $('#ic_no').prop('readonly', false);
                $('select[name="member_id"]').children('option[value=""]').prop('selected', true);
                $('input[name="telephone"]').val('');
                $('input[name="ic_no"]').val('');
            } else if($('input[name="custom"]').prop("checked") == false){
                $('#telephone').prop('readonly', true);
                $('#ic_no').prop('readonly', false);
                $('#custom_name').css('display', 'none');
                $('#exiting_name').css('display', 'block');
                $('input[name="member_name"]').val('');
                $('input[name="ic_no"]').val('');
                $('input[name="telephone"]').val('');
            }
        }

        $('input[name="custom"]').click(function(){
            checkNew();
        });
        $('[data-get="member"]').change(function (e) {
            var id = $(this).children(":selected").val();
            $.ajax({
                type: "get",
                url: "/member-data/"+id,
                cache: false,
                dataType: "json",
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    console.log(response)
                    $('#telephone').val(response.mobile_phone);
                    $('#ic_no').val(response.ic_no);
                },
                error: function (error) {
                    console.log(error);
                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/family.blade.php ENDPATH**/ ?>