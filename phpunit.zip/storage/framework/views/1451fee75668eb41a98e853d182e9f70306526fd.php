<div class="relation col-12">
    <div class="row mt-3">
        <div class="col-12">
            <h4>Dependants</h4>
        </div>
        <div class="col-md-11 col-12 mb-3">
            <div class="row relation-header">
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Name</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Ic No</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Telephone</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Relation</span></div>
            </div>
        </div>
    </div>


    <div class="relation-list">
        <?php
            $i = 1;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $member['relation_ships']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row mb-3">
                <div class="col-9 col-md-11">
                    <div class="row">
                        <div class="col-md-3 col-12">
                            <span><?php echo e($i); ?>.<?php echo e(" ". $relation['relatedTo']['name']); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e($relation['relatedTo']['ic_no']); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e(($relation['relatedTo']['telephone_one'])); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e($relation['relationship']['name']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="row">
                
                <div class="col-9 col-md-11">
                    <p class="text-primary">No Dependants Yet</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/layouts/member-dependents.blade.php ENDPATH**/ ?>