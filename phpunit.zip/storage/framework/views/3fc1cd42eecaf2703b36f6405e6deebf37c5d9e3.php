<div class="relation col-12">
    <div class="row mt-3">
        <div class="col-12">
            <h4>Dependants</h4>
        </div>
        <div class="col-md-11 col-12">
            <div class="row relation-header">
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Name</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Ic No</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block">Telephone</span></div>
                <div class="col-md-3 col-12"><span class="d-none d-md-inline-block required">Relation</span></div>
            </div>
        </div>
    </div>

    <form action="<?php echo e(route('relation.store')); ?>" method="POST">
        <div class="row align-items-center" id="relationShip">
            
            <div class="col-md-11 col-12">
                <?php echo csrf_field(); ?>
                <div class="row align-items-center">
                    <input type="hidden" name="member_id" value="<?php echo e($member['id']); ?>">
                    <div class="col-12">
                        <input type="checkbox" name="custom" <?php if( old('custom') == 'on'): ?> checked <?php endif; ?> class="chk-col-light-blue" id="md_checkbox_7">
                        <label for="md_checkbox_7"> New</label>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="form-group <?php $__errorArgs = ['related_to_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exiting_name">
                            <select class="form-control custom-select <?php $__errorArgs = ['related_to_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="related_to_id" data-get="member">
                                <option value="">Select Member</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member['id']); ?>" <?php if( old('related_to_id') == $member['id']): ?> selected <?php endif; ?>><?php echo e($member['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['related_to_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="invalid-feedback d-block form-control-feedback"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="custom_name">
                            <input class="form-control <?php $__errorArgs = ['member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="member_name" placeholder="Name" value="<?php echo e(old('member_name')); ?>">
                            <?php $__errorArgs = ['member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="form-control-feedback d-block invalid-feedback"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="form-group <?php $__errorArgs = ['ic_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <input class="form-control <?php $__errorArgs = ['ic_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="ic_no" placeholder="Ic No" value="<?php echo e(old('ic_no')); ?>" id="ic_no" readonly>
                            <?php $__errorArgs = ['ic_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="invalid-feedback d-block form-control-feedback"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="form-group <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <input class="form-control <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="telephone" placeholder="Telephone" value="<?php echo e(old('telephone')); ?>" id="telephone">
                            <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="invalid-feedback d-block form-control-feedback"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="form-group <?php $__errorArgs = ['relation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <select class="form-control custom-select <?php $__errorArgs = ['relation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-control-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="relation_id">
                                <option value="">Select Relation</option>
                                <?php $__currentLoopData = $relations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($relation['id']); ?>" <?php if( old('relation_id') == $relation['id']): ?> selected <?php endif; ?>><?php echo e($relation['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['relation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="invalid-feedback d-block form-control-feedback"> <?php echo e($message); ?> </small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-1 col-12 text-center text-md-left">
                <div class="form-group">
                    <button class="btn btn-primary" type="submit"><i class="mdi mdi-check d-none d-md-inline-block"></i> <span class="d-block d-md-none">Save</span></button>
                </div>
            </div>
        </div>
    </form>


    <div class="relation-list">
        <?php
            $i = 1;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row">
                
                <div class="col-9 col-md-11">
                    <div class="row align-items-center">
                        <div class="col-md-3 col-12">
                            <span><?php echo e($i); ?>.<?php echo e(" ". $relation['relatedTo']['name']); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e($relation['relatedTo']['ic_no']); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e(($relation['relatedTo']['mobile_phone'])); ?></span>
                        </div>
                        <div class="col-md-3 col-12">
                            <span><?php echo e($relation['relationship']['name']); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-3 col-md-1 hideOnPrint py-2">
                    <form class="d-inline-block" method="post" action="<?php echo e(route('relation.destroy', $relation['id'])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn text-white btn-danger"><i class="mdi mdi-delete"></i></button>
                    </form>
                </div>
            </div>
            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="row">
                
                <div class="col-9 col-md-11">
                    <p class="text-primary">No Dependants Yet</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/layouts/dependents.blade.php ENDPATH**/ ?>