<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
<h1 class="text-3xl font-bold underline">
    Hello world!
</h1>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\fitness\frontend1\resources\views/app.blade.php ENDPATH**/ ?>