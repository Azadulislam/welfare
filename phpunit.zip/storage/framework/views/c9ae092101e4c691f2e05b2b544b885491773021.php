<?php $__env->startSection('content'); ?>
    <?php $member = $khairat_member->member ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Database List</h4>
                            </div>
                        </div>
                        <h4><?php echo e($member['name']); ?></h4>
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="form-group row align-items-center">
                                    <label class="col-sm-3 col-form-label">Full Name</label>
                                    <div class="col-sm-9">
                                        <?php echo e($member['name']); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group row align-items-center">
                                    <label class="col-sm-3 col-form-label">Other Name</label>
                                    <div class="col-sm-9">
                                        <?php echo e($member['name']); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group row align-items-center">
                                    <label class="col-sm-3 col-form-label">Telephone</label>
                                    <div class="col-sm-9">
                                        <?php echo e($member['telephone_one']); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group row align-items-center">
                                    <label class="col-sm-3 col-form-label">Other Telephone</label>
                                    <div class="col-sm-9">
                                        <?php echo e($member['telephone_one']); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <div class="form-group row align-items-center">
                                    <label class="col-sm-3 col-form-label">Address</label>
                                    <div class="col-sm-9">
                                        <?php echo e($member['home_address1']); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = array(
                                    array('label'=>'City', 'value'=> $member->home_city),
                                    array('label'=>'Postcode', 'value'=> $member->home_postcode),
                                    array('label'=>'District', 'value' => $member->home_district),
                                    array('label'=>'State','value' => $member->home_state),
                                    array('label'=>'Benificiary','value' => $member->home_state),
                                    array('label'=>'Birth Date','value' => $member->bitth_date),
                                    array('label'=>'IC','value' => $member->ic_no),
                                    array('label'=>'Job','value' => $member->job),
                                    array('label'=>'Guardian','value' => $member->jobjob),
                                    array('label'=>'Asnaf Status','value' => $member->jobjob),
                                    ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="form-label">
                                            <span><?php echo e($data['label']); ?></span>
                                        </label>
                                        <div class="">
                                            <?php echo e($data['value']); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = array(
                                    array('src' => $member->attache_file1),
                                    array('src' => $member->attache_file2),
                                    array('src' => $member->attache_file3),
                                    array('src' => $member->attache_file4)
                                ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group mb-3 col-md-3 col-sm-4 col-6">
                                    <label for="exampleInputCity1">Image file</label>
                                    <img style="width: 100%;height: calc(100px + 5vw)" src="<?php echo e(asset("images/".$src['src'] )); ?>" alt="">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <?php echo $__env->make('layouts.member-dependents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/khairat-single-member.blade.php ENDPATH**/ ?>