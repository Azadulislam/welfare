<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Registration Of Welfare Help</h4>
                            </div>
                        </div>
                        <form class="forms-sample" action="<?php echo e(route('welfare.store')); ?>" enctype="multipart/form-data" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="form-group is-invalid">
                                <label>Help Category</label>
                                <div class="row">
                                    <?php $__currentLoopData = $help_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <?php echo e($category['name']); ?>

                                                    <input type="radio" name="help_cat_id" value="<?php echo e($category['id']); ?>"  <?php if(old('help_cat_id') == $category['id']): ?> checked <?php endif; ?>
                                                           class="form-check-input rounded-0">
                                                </label>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['help_cat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-12 required">
                                    <label for=""><span>Select Member</span></label>
                                    <select class="form-control" id="search_key">
                                    </select>
                                    <input type="hidden" name="member_id" value="<?php echo e(old('member_id')); ?>">
                                    <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Applicant Mobile phone', 'name'=>'mobile_phone'),
                                        array('label'=>'Telephone (Home)', 'name'=>'telephone_one'),
                                        array('label'=>'IC No', 'name'=>'ic_no'),
                                        array('label'=>'Marital Status', 'name'=>'marital_status'),
                                        array('label'=>'Jalan', 'name'=>'jalan'),
                                        array('label'=>'Date Of Birth', 'name'=>'birth_date'),
                                        array('label'=>'Seksyen', 'name'=>'seksyen'),
                                        array('label'=>'Date Starts of Stay', 'name'=>'start_of_stay')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group row align-items-center">
                                            <label class="col-sm-3 col-form-label"><?php echo e($info['label']); ?></label>
                                            <div class="col-sm-9">
                                                <input type="text" readonly name="<?php echo e($info['name']); ?>" value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group">
                                <label>Pernah menerima bantuan dari institusi zakat</label>
                                <div class="row">
                                    <?php for($i=0;$i<5;$i++): ?>
                                        <?php
                                            $cyear = \Carbon\Carbon::today()->format('Y');
                                            $start = $cyear - 5;
                                            $end = ($cyear) + (5);
                                        ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <select class="form-control" name="years[]">
                                                <option>Select Year</option>
                                                <?php for($start ; $start < $end; $start++): ?>
                                                    <option value="<?php echo e($start); ?>"  <?php if(old('years[]') == $start): ?> selected <?php endif; ?>><?php echo e($start); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                    <?php endfor; ?>
                                </div>
                                <?php $__errorArgs = ['years'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Profession</label>
                                <div class="row">
                                    <?php $__currentLoopData = array('Job', 'Un Employed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <input type="radio" name="current_job"  value="<?php echo e($job); ?>"  <?php if(old('current_job') == $job): ?> checked <?php endif; ?>
                                                           class="form-check-input rounded-0">
                                                    <?php echo e($job); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['current_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group row align-items-center unemployed collapsed">
                                <label class="">Un Employed Reason</label>
                                <div class="col-sm-9">
                                    <input type="text" name="unemployed_reason" class="form-control"/>
                                </div>
                                <?php $__errorArgs = ['unemployed_reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Swctor</label>
                                <div class="row">
                                    <?php $__currentLoopData = $job_sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <input type="radio" name="job_sector_id" value="<?php echo e($sector['id']); ?>"
                                                           class="form-check-input">
                                                    <?php echo e($sector['name']); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['job_sector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Status of Current Place Of Stay</label>
                                <div class="row">
                                    <?php $__currentLoopData = $home_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-2 col-md-3 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                <input type="radio" name="home_status_id" value="<?php echo e($place['id']); ?>"  <?php if(old('home_status_id') == $place['id']): ?> checked <?php endif; ?>
                                                           class="form-check-input">
                                                    <?php echo e($place['name']); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['home_status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleTextarea1">Summary</label>
                                <textarea class="form-control" name="summary" id="exampleTextarea1" rows="4"><?php echo e(old('summary')); ?></textarea>
                                <?php $__errorArgs = ['summary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <?php for($i=0;$i< 4; $i++): ?>
                                    <div class="form-group mb-3 col-md-3 col-sm-4 col-6">
                                        <label for="exampleInputCity1">Image file</label>
                                        <input type="file" name="images[]" class="dropify" data-height="250"/>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Name Of Complaint', 'name'=>'informer_name', 'type' => 'text'),
                                        array('label'=>'Date', 'name'=>'date_apply', 'type' => 'date')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group row align-items-center">
                                            <label class="col-sm-3 col-form-label"><?php echo e($info['label']); ?></label>
                                            <div class="col-sm-9">
                                                <input type="<?php echo e($info['type']); ?>" placeholder="<?php echo e($info['label']); ?>" name="<?php echo e($info['name']); ?>" value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dist/js/dropify.js')); ?>"></script>
    <script>
        let keywordEl = $('#search_key');
        $eventSelect = keywordEl.select2({
            placeholder: "Search Name/IC No",
            ajax: {
                method: 'POST',
                url: '/search-member',
                data: function (params) {
                    console.log(params)
                    var query = {
                        search: params.term,
                        type: 'public'
                    }
                    return query;
                },
                processResults: function (data) {
                    let items = [];
                    $(data).each((index, item)=>{
                        items.push({id: item.id, text: item.name})
                    })
                    return {
                        results:items,
                    };
                }
            },
            change: (e)=>{
                console.log(e)
            }

        });
        $eventSelect.on("change", function (e) { fetchData($(e.target).val()) });
        function fetchData(id){
            $.ajax({
                'url': '/member-data/'+id,
                'Method': 'POST',
                'content-type': 'json',
                'processData': false,
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                success:(response)=> {
                    let names = [
                        {name: 'member_id', value: response.id},
                        {name: 'mobile_phone', value: response.mobile_phone},
                        {name: 'telephone_one', value: response.telephone},
                        {name: 'home_address1', value: response.home_address1},
                        {name: 'seksyen', value: response.seksyen},
                        {name: 'ic_no', value: response.ic_no},
                        {name: 'birth_date', value: response.birth_date},
                        {name: 'telephone', value: response.telephone},
                        {name: 'start_of_stay', value: response.start_of_stay},
                        {name: 'marital_status', value: response.marital_status}
                    ]
                    $(names).each((index, name) => {
                        $('[name="' + name.name + '"]').val(name.value)
                    })
                    $('[name="member_status_ids[]"]').each((index, checkbox)=>{
                        let ids = JSON.parse(response.member_status_ids);
                        if(Array.isArray(ids)){
                            if(ids.includes(checkbox.value)){
                                $(checkbox).prop('checked', true)
                            }
                        }else{
                            $(checkbox).prop('checked', false)
                        }
                    })
                }
            })
        }

        let current_job = $("input[name='current_job']");
        current_job.click(()=>{
            checkJOb();
        })
        checkJOb();
        function checkJOb(){
            if($("input[name='current_job']:checked").val() === 'Un Employed'){
                $('.unemployed').show();
            }else{
                $('.unemployed').hide();
            }
        }

        $('.dropify').dropify();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/add-welfare.blade.php ENDPATH**/ ?>