<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h4 class="card-title mb-3">Personal Profile Registration</h4>
                            </div>
                        </div>
                        <form class="forms-sample" action="<?php echo e(route('member.store')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Full Name', 'name'=>'name'),
                                        array('label'=>'IC No', 'name'=>'ic_no')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 col-12">
                                        <div class="form-group row align-items-center required">
                                            <label class="col-sm-3 col-form-label">
                                                <span><?php echo e($info['label']); ?></span>
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="text" name="<?php echo e($info['name']); ?>"
                                                       value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                            </div>
                                            <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group is-invalid row required align-items-center">
                                <label class="col-md-3 col-6 mb-0">
                                    <span>Member Type</span>
                                </label>
                                <div class="col-md-9 col-6 row">
                                    <?php $__currentLoopData = $member_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <?php echo e($job['name']); ?>

                                                    <input type="checkbox" name="member_status_ids[]"
                                                           <?php if(is_array(old('member_status_ids'))): ?> <?php if( in_array($job['id'], old('member_status_ids') )): ?> checked
                                                           <?php endif; ?> <?php endif; ?> value="<?php echo e($job['id']); ?>"
                                                           class="form-check-input rounded-0">
                                                </label>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['member_status_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Date of Birth', 'name'=>'birth_date', 'type' => 'date', 'required' => true),
                                        array('label'=>'Citizenship', 'name'=>'citizenship', 'type' => 'select', 'required'=> true, 'values' => $citizenshipCounties, 'default' => 'Select Country'),
                                        array('label'=>'Gender', 'name'=>'gender', 'type' => 'select', 'required' => false, 'default' => 'Select Gender', 'values' => $genders),
                                        array('label'=>'Race', 'name'=>'race', 'type' => 'select', 'required' => false, 'default' => 'Select Country', 'values' => $races),
                                        array('label'=>'Religion', 'name'=>'religion', 'type' => 'select', 'required' => false, 'default' => 'Select Religion', 'values' => $religions),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                            <?php elseif($data['type'] == 'select'): ?>
                                                <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                    <option value=""><?php echo e($data['default']); ?></option>
                                                    <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value['id'] ?? $value); ?>"
                                                                <?php if(old($data['name']) == $value['id'] ?? $value): ?> selected <?php endif; ?>><?php echo e($value['name'] ?? $value); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>


                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group is-invalid row align-items-center required">
                                <label class="col-md-3 col-6 mb-0">
                                    <span>Marital Status</span>
                                </label>
                                <div class="col-md-9 col-6 row">
                                    <?php $__currentLoopData = $maritalStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-6">
                                            <div class="form-check form-check-warning">
                                                <label class="form-check-label">
                                                    <?php echo e($status['name']); ?>

                                                    <input type="radio" name="marital_status_id"
                                                           <?php if(old('marital_status_id') == $status['id']): ?> checked
                                                           <?php endif; ?> value="<?php echo e($status['id']); ?>"
                                                           class="form-check-input rounded-0">
                                                </label>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['member_status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group is-invalid">
                                <label class="">
                                    <span>Address as in IC No.</span>
                                </label>
                                <div class="row">
                                    <?php $__currentLoopData = array(
                                            array('label'=>'Address Line 1', 'name'=>'ic_address1'),
                                            array('label'=>'Address Line 2', 'name'=>'ic_address2'),
                                            array('label'=>'Address Line 3', 'name'=>'ic_address3'),
                                            ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group row align-items-center">
                                                <label class="col-sm-3 col-form-label"><?php echo e($info['label']); ?></label>
                                                <div class="col-sm-9">
                                                    <input type="text" name="<?php echo e($info['name']); ?>"
                                                           value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                                </div>
                                                <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback d-block" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = array(
                                            array('label'=>'Postcode', 'name'=>'ic_postcode', 'type' => 'text', 'required' => false),
                                            array('label'=>'Town', 'name'=>'ic_city', 'type' => 'text', 'required' => false),
                                            array('label'=>'District', 'name'=>'ic_district', 'type' => 'text', 'required' => false),
                                            array('label'=>'State', 'name'=>'ic_state_id', 'type' => 'select', 'required'=> false, 'default' => 'Select State', 'values' => $states),
                                            ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-6">
                                            <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                                <label class="form-label">
                                                    <span><?php echo e($data['label']); ?></span>
                                                </label>
                                                <?php if($data['type'] == 'text' || $data['type'] == 'date' || $data['type'] == 'email'): ?>
                                                    <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                           class="form-control"/>
                                                <?php elseif($data['type'] == 'select'): ?>
                                                    <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                        <option value=""><?php echo e($data['default']); ?></option>
                                                        <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e(old($value['id'])); ?>"
                                                                    value="<?php echo e(old($data['name'])); ?>"><?php echo e($value['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>

                                                <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="form-group is-invalid">
                                <label class="">
                                    <span>Latest Address</span>
                                </label>
                                <div class="row">
                                    <?php $__currentLoopData = array(
                                            array('label'=>'Address Line 1', 'name'=>'home_address1', 'required' => true),
                                            array('label'=>'Address Line 2', 'name'=>'home_address2', 'required' => false),
                                            array('label'=>'Address Line 3', 'name'=>'home_address3', 'required' => false),
                                            ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-12">
                                            <div
                                                class="form-group row align-items-center <?php if($info['required']): ?> required <?php endif; ?>">
                                                <label class="col-sm-3 col-form-label">
                                                    <span><?php echo e($info['label']); ?></span>
                                                </label>
                                                <div class="col-sm-9">
                                                    <input type="text" name="<?php echo e($info['name']); ?>"
                                                           value="<?php echo e(old($info['name'])); ?>" class="form-control"/>
                                                </div>
                                                <?php $__errorArgs = [$info['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="row">
                                    <?php $__currentLoopData = array(
                                            array('label'=>'Postcode', 'name'=>'home_postcode', 'type' => 'text', 'required' => false),
                                            array('label'=>'Town', 'name'=>'home_city', 'type' => 'text', 'required' => false),
                                            array('label'=>'District', 'name'=>'home_district', 'type' => 'text', 'required' => false),
                                            array('label'=>'State', 'name'=>'home_state_id', 'type' => 'select', 'required'=> false, 'default' => 'Select State', 'values' =>$states),
                                            ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-6">
                                            <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                                <label class="form-label">
                                                    <span><?php echo e($data['label']); ?></span>
                                                </label>
                                                <?php if($data['type'] == 'text' || $data['type'] == 'date' || $data['type'] == 'email'): ?>
                                                    <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                           value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                                <?php elseif($data['type'] == 'select'): ?>
                                                    <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                        <option value=""><?php echo e($data['default']); ?></option>
                                                        <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value['id']); ?>"
                                                                    <?php if(old($data['name']) == $value['name']): ?> selected <?php endif; ?>><?php echo e($value['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>


                                                <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <?php $__currentLoopData = array(
                                        array('label'=>'Telephone (Home)', 'name'=>'telephone_one', 'type' => 'text', 'required' => false),
                                        array('label'=>'Telephone (Hand phone)', 'name'=>'mobile_phone', 'type' => 'text', 'required' => true),
                                        array('label'=>'Email', 'name'=>'email', 'type' => 'email', 'required' => false),
                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-6">
                                        <div class="form-group <?php if($data['required']): ?> required <?php endif; ?>">
                                            <label class="form-label">
                                                <span><?php echo e($data['label']); ?></span>
                                            </label>
                                            <?php if($data['type'] == 'text' || $data['type'] == 'date' || $data['type'] == 'email'): ?>
                                                <input type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>"
                                                       value="<?php echo e(old($data['name'])); ?>" class="form-control"/>
                                            <?php elseif($data['type'] == 'select'): ?>
                                                <select class="form-control" name="<?php echo e($data['name']); ?>">
                                                    <option><?php echo e($data['default']); ?></option>
                                                    <?php $__currentLoopData = $data['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value['name']); ?>"
                                                                <?php if(old($data['name']) == $value['name']): ?> selected <?php endif; ?>><?php echo e($value['name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                            <?php $__errorArgs = [$data['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="row">
                                <?php for($i=0;$i< 4; $i++): ?>
                                    <div class="form-group mb-3 col-md-3 col-sm-4 col-6">
                                        <label for="exampleInputCity1">Image file</label>
                                        <input type="file" name="images[]" class="dropify" data-height="250"/>
                                        <input type="hidden" value="<?php echo e($i); ?>" name="oldImages[<?php echo e($i); ?>]"/>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dist/js/dropify.js')); ?>"></script>
    <script>
        $('.dropify').dropify();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Web project\code\phpstorm\welfare\resources\views/add-member.blade.php ENDPATH**/ ?>