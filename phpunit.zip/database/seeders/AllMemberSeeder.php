<?php

namespace Database\Seeders;

use App\Models\AllMember;
use App\Models\WelfareService;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AllMemberSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $all_members = array(
            array('id' => '1','name' => 'developer','home_address1' => 'Rajshahi','home_address2' => NULL,'home_address3' => NULL,'home_city' => NULL,'home_postcode' => NULL,'home_district' => NULL,'home_state_id' => '1','home_status_id' => NULL,'ic_address1' => NULL,'ic_address2' => NULL,'ic_address3' => NULL,'ic_city' => NULL,'ic_postcode' => NULL,'ic_district' => NULL,'ic_state_id' => NULL,'family_status_id' => NULL,'citizenship_id' => '1','telephone_one' => NULL,'telephone2' => NULL,'mobile_phone' => '0122222222','email' => NULL,'name2' => NULL,'birth_date' => '2023-01-12','ic_no' => '5243543523455','race_id' => NULL,'religion_id' => NULL,'marital_status_id' => '1','start_of_stay' => NULL,'end_of_stay' => NULL,'active_status' => NULL,'active_status_note' => NULL,'job' => NULL,'gender_id' => NULL,'attache_file1' => NULL,'attache_file2' => NULL,'attache_file3' => NULL,'attache_file4' => NULL,'last_edited_date' => '2023-01-21','current_job' => NULL,'current_job_sector_id' => NULL,'unemployed_reason' => NULL,'member_status_ids' => '["1","3"]','created_at' => '2023-01-21 08:55:08','updated_at' => '2023-01-21 08:55:08'),
            array('id' => '2','name' => 'AZADUL ISLAM','home_address1' => 'Rajshahi','home_address2' => 'Rajshahi','home_address3' => 'Rajshahi','home_city' => 'Rajshahi','home_postcode' => '3432','home_district' => 'Rajshahi','home_state_id' => '1','home_status_id' => NULL,'ic_address1' => 'Natore Sador','ic_address2' => 'Natore Sador','ic_address3' => 'Natore Sador','ic_city' => 'Notre','ic_postcode' => '231232','ic_district' => 'Natoer','ic_state_id' => NULL,'family_status_id' => NULL,'citizenship_id' => '3','telephone_one' => '87987987','telephone2' => NULL,'mobile_phone' => '0122222222','email' => NULL,'name2' => NULL,'birth_date' => '2023-01-12','ic_no' => '5243543523455fds','race_id' => NULL,'religion_id' => NULL,'marital_status_id' => '1','start_of_stay' => NULL,'end_of_stay' => NULL,'active_status' => NULL,'active_status_note' => NULL,'job' => NULL,'gender_id' => '1','attache_file1' => NULL,'attache_file2' => 'a09ab2d9c5-background.jpg','attache_file3' => NULL,'attache_file4' => NULL,'last_edited_date' => '2023-01-28','current_job' => NULL,'current_job_sector_id' => NULL,'unemployed_reason' => NULL,'member_status_ids' => '["1","2"]','created_at' => '2023-01-28 09:27:22','updated_at' => '2023-01-28 09:27:22')
        );
        AllMember::insert($all_members);

        $welfare_service = array(
            array('id' => '1','name' => 'developer','home_address1' => 'Rajshahi','home_address2' => NULL,'home_address3' => NULL,'home_city' => NULL,'home_postcode' => NULL,'home_district' => NULL,'home_state_id' => '1','home_status_id' => NULL,'ic_address1' => NULL,'ic_address2' => NULL,'ic_address3' => NULL,'ic_city' => NULL,'ic_postcode' => NULL,'ic_district' => NULL,'ic_state_id' => NULL,'family_status_id' => NULL,'citizenship_id' => '1','telephone_one' => NULL,'telephone2' => NULL,'mobile_phone' => '0122222222','email' => NULL,'name2' => NULL,'birth_date' => '2023-01-12','ic_no' => '5243543523455','race_id' => NULL,'religion_id' => NULL,'marital_status_id' => '1','start_of_stay' => NULL,'end_of_stay' => NULL,'active_status' => NULL,'active_status_note' => NULL,'job' => NULL,'gender_id' => NULL,'attache_file1' => NULL,'attache_file2' => NULL,'attache_file3' => NULL,'attache_file4' => NULL,'last_edited_date' => '2023-01-21','current_job' => NULL,'current_job_sector_id' => NULL,'unemployed_reason' => NULL,'member_status_ids' => '["1","3"]','created_at' => '2023-01-21 08:55:08','updated_at' => '2023-01-21 08:55:08'),
        );
        WelfareService::insert($welfare_service);
    }
}
